#include "task_list_panel.h"
#include "add_task_dialog.h"
#include "add_event_dialog.h"
#include <QLabel>
#include <QVBoxLayout>
#include <QListWidget>
#include <QPushButton>
#include <QScrollArea>
#include <QToolButton>
#include <QStyle>
#include <QApplication>

#include "task_data.h"

TaskListPanel::TaskListPanel(QWidget *parent)
    : QWidget(parent)
{
    // main layout setup
    layout = new QVBoxLayout(this);             //create a vertical layout for stacking elements
    layout->setSpacing(10);                     // add space between widgets
    layout->setContentsMargins(10, 10, 10, 10); // add padding inside the panel

    // header
    // create a bold header label
    QLabel *tasksHeader = new QLabel("Tasks", this);
    tasksHeader->setStyleSheet(
        "font-weight: bold;"
        "font-size: 20px;"
        "margin-bottom: 10px;"
        "color: #000;");
    // add it to the layout at the top of the panel
    layout->addWidget(tasksHeader);

    // task list widget
    // create a list to hold tasks
    taskList = new QListWidget(this);
    taskList->setStyleSheet(
        "QListWidget {"
        "   background-color: #F3F3F3;"
        "   border: none;"
        "   padding: 6px;"
        "}"
        "QListWidget::item {"
        "   background: transparent;"
        "   border: none;"
        "   margin: 4px;"
        "}"
        "QListWidget::item:selected {"
        "   background: transparent;"
        "}");
    // disable selection highlighting
    taskList->setSelectionMode(QAbstractItemView::NoSelection);

    // add the task list to the layout
    layout->addWidget(taskList, 1);

    // add event button (placed above Add Task)
    addEventButton = new QPushButton("+ Add Event", this);
    addEventButton->setStyleSheet(
        "QPushButton { background-color: #2196F3; color: white; font-weight: bold; border-radius: 6px; padding: 6px; }"
        "QPushButton:hover { background-color: #1976D2; }"
    );
    layout->addWidget(addEventButton);

    // add task button
    addButton = new QPushButton("+ Add Task", this);
    addButton->setStyleSheet(
        "QPushButton {"
        "   background-color: #4CAF50;"
        "   color: white;"
        "   font-weight: bold;"
        "   border-radius: 6px;"
        "   padding: 6px;"
        "}"
        "QPushButton:hover {"
        "   background-color: #45A049;"
        "}");
    layout->addWidget(addButton);

    // connect the button click to open the add task dialog
    connect(addButton, &QPushButton::clicked, this, &TaskListPanel::openAddTaskDialog);
    connect(addEventButton, &QPushButton::clicked, this, &TaskListPanel::openAddEventDialog);
}

void TaskListPanel::openAddTaskDialog()
{
   //open the add task dialog window
    AddTaskDialog dialog(this);

    //if user presses add
    if (dialog.exec() == QDialog::Accepted)
    {
        //get data entered by user
        TaskData newTask = dialog.getTaskData();

        //create new list item for task list
        QListWidgetItem *item = new QListWidgetItem(taskList);
        item->setSizeHint(QSize(260, 120));

        // create container for task info
        QWidget *container = new QWidget(taskList);
        container->setObjectName("taskCard");
        container->setStyleSheet(
            "#taskCard {"
            "  border: 2px solid #444;"
            "  border-radius: 10px;"
            "  background-color: #FFFFFF;"
            "  padding: 12px;"
            "  margin: 4px;"
            "}");

        //vertical layout for everything inside the task card
        QVBoxLayout *mainLayout = new QVBoxLayout(container);
        mainLayout->setContentsMargins(10, 8, 10, 8);
        mainLayout->setSpacing(6);

        //Top row: name and buttons
        QHBoxLayout *topRow = new QHBoxLayout();
        topRow->setContentsMargins(0, 0, 0, 0);
        topRow->setSpacing(6);

        //task title label
        QLabel *nameLabel = new QLabel(newTask.name, container);
        nameLabel->setStyleSheet("font-weight: bold; font-size: 15px; color: black;");

        // edit button
        QToolButton *editButton = new QToolButton(container);
        editButton->setText("✎");
        editButton->setToolTip("Edit Task");
        editButton->setFixedSize(22, 22);
        editButton->setStyleSheet(
            "QToolButton { border: none; font-size: 30px; }"
            "QToolButton:hover { background-color: #EAEAEA; border-radius: 4px; }");

        //delete button 
        QToolButton *deleteButton = new QToolButton(container);
        deleteButton->setText("🗑️");
        deleteButton->setToolTip("Delete Task");
        deleteButton->setFixedSize(22, 22);
        deleteButton->setStyleSheet(
            "QToolButton { border: none; font-size: 18px; }"
            "QToolButton:hover { background-color: #FFD6D6; border-radius: 4px; }");

        //horizontal layout for both buttons
        QHBoxLayout *buttonLayout = new QHBoxLayout();
        buttonLayout->addWidget(editButton);
        buttonLayout->addWidget(deleteButton);
        buttonLayout->setAlignment(Qt::AlignRight);

        //add name and buttons to top row
        topRow->addWidget(nameLabel, 1);
        topRow->addLayout(buttonLayout);

        // info labels (due, effort, priority)
        QLabel *dueLabel = new QLabel("Due: " + newTask.dueDate.toString("dddd"), container);
        QLabel *effortLabel = new QLabel("Effort: " + QString::number(newTask.effortHours) + " hrs", container);
        QLabel *priorityLabel = new QLabel("Priority: " + newTask.priority, container);

        //set font style for info labels
        for (auto *lbl : {dueLabel, effortLabel, priorityLabel})
            lbl->setStyleSheet("font-size: 13px; color: black;");

        //add all elements to the main layout
        mainLayout->addLayout(topRow);
        mainLayout->addWidget(dueLabel);
        mainLayout->addWidget(effortLabel);
        mainLayout->addWidget(priorityLabel);
        mainLayout->addStretch(1);

        //warpper to ensure full box fits properly
        QWidget *wrapper = new QWidget(taskList);
        QVBoxLayout *wrapperLayout = new QVBoxLayout(wrapper);
        wrapperLayout->setContentsMargins(8, 8, 8, 8);
        wrapperLayout->addWidget(container);
        wrapper->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
        item->setSizeHint(wrapper->sizeHint());

        //add card to the list
        taskList->addItem(item);
        taskList->setItemWidget(item, wrapper);

        emit taskCreated(newTask);

        //configure list layout and scrolling
        taskList->setWordWrap(true);    //allow long text
        taskList->setSpacing(10);   //space between items
        taskList->setUniformItemSizes(false);
        taskList->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        taskList->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
        taskList->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        //style list widget background
        taskList->setStyleSheet(
            "QListWidget {"
            "  background-color: #F4F4F4;"
            "  border: none;"
            "  padding: 8px;"
            "}"
            "QScrollBar:horizontal { height: 0px; }"
        );

        // Connect buttons to functions
        connect(editButton, &QToolButton::clicked, [=]()
                { editTask(item); });
        connect(deleteButton, &QToolButton::clicked, [=]()
                { deleteTask(item); });
    }
}

void TaskListPanel::openAddEventDialog()
{
    AddEventDialog dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        CourseEvent ev = dlg.event();
        // notify parent (MainWindow) that an event was created so it can be
        // inserted into the calendar's event list and displayed in the grid.
        emit eventAdded(ev);
    }
}

void TaskListPanel::editTask(QListWidgetItem *item)
{
    QWidget *widget = taskList->itemWidget(item);
    if (!widget)
        return;

    // Get all labels
    QList<QLabel *> labels = widget->findChildren<QLabel *>();
    if (labels.isEmpty())
        return;

    QLabel *nameLabel = labels.at(0);
    QLabel *dueLabel = labels.at(1);
    QLabel *effortLabel = labels.at(2);
    QLabel *priorityLabel = labels.at(3);

    AddTaskDialog dialog(this);
    dialog.setWindowTitle("Edit Task");

    if (dialog.exec() == QDialog::Accepted)
    {
        TaskData updated = dialog.getTaskData();

        nameLabel->setText(updated.name);
        dueLabel->setText("Due: " + updated.dueDate.toString("dddd"));
        effortLabel->setText("Effort: " + QString::number(updated.effortHours) + " hrs");
        priorityLabel->setText("Priority: " + updated.priority);
    }
}

void TaskListPanel::deleteTask(QListWidgetItem *item)
{
    int row = taskList->row(item);
    delete taskList->takeItem(row);
}
