#include "add_task_dialog.h"
#include "ui_add_task_dialog.h"
#include "task_data.h"
#include <QMessageBox>
#include <QVariant>
#include <QList>

//constructor to set up the add task window
AddTaskDialog::AddTaskDialog(QWidget *parent)
    : QDialog(parent), ui(new Ui::AddTaskDialog)
{
    //connects the .ui files widgets 
    ui->setupUi(this);

    populateDueDateOptions();
    populateEffortOptions();

    //set the windows title bar text "Add Task"
    setWindowTitle("Add Task");
    //ensure the window comfortably fits the form fields without clipping
    setMinimumSize(380, 300);
    resize(380, 300);
    //Light grey background
    setStyleSheet("QDialog { background-color: #FAFAFA; }");

    // style for all input fields
    QString inputStyle =
        "QLineEdit, QComboBox { "
        "border: 1px solid #CCCCCC; border-radius: 6px; padding: 4px 6px; min-height: 24px; }";
    setStyleSheet(styleSheet() + inputStyle);

    //connect the dialog buttons
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, &AddTaskDialog::onAccepted);
    connect(ui->buttonBox, &QDialogButtonBox::rejected, this, &AddTaskDialog::reject);
}

//destructor
AddTaskDialog::~AddTaskDialog() { delete ui; }

//runs when "Add" is pressed
void AddTaskDialog::onAccepted()
{
    task.name = ui->nameLineEdit->text();   //read the task name from the text box

    const QVariant dueData = ui->dueDateComboBox->currentData();
    if (!dueData.isValid()) {
        QMessageBox::warning(this, tr("Missing Due Date"), tr("Please select a due date."));
        return;
    }
    task.dueDate = dueData.toDate(); // get the selected due date

    const QVariant effortData = ui->effortComboBox->currentData();
    if (!effortData.isValid()) {
        QMessageBox::warning(this, tr("Missing Effort"), tr("Please choose an estimated effort."));
        return;
    }
    task.effortHours = effortData.toDouble();   //get the number of hours
    task.priority = ui->priorityComboBox->currentText();    //get the chosen priority from the dropdown
    accept();
}

// Return the TaskData struct holding all the entered info
TaskData AddTaskDialog::getTaskData() const
{
    return task;
}

void AddTaskDialog::populateDueDateOptions()
{
    ui->dueDateComboBox->clear();

    const QDate today = QDate::currentDate();
    const int daysAhead = 30;

    for (int offset = 0; offset <= daysAhead; ++offset) {
        const QDate date = today.addDays(offset);
        const QString label = date.toString("ddd, MMM d");
        ui->dueDateComboBox->addItem(label, date);
    }

    ui->dueDateComboBox->setCurrentIndex(0);
}

void AddTaskDialog::populateEffortOptions()
{
    ui->effortComboBox->clear();

    const QList<double> effortChoices = {
        0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 12.0, 15.0, 20.0
    };

    for (double hours : effortChoices) {
        const bool isWhole = qFuzzyIsNull(hours - static_cast<int>(hours));
        QString label = isWhole
            ? QString("%1 hrs").arg(static_cast<int>(hours))
            : QString("%1 hrs").arg(hours, 0, 'f', 1);
        ui->effortComboBox->addItem(label, hours);
    }

    if (ui->effortComboBox->count() > 0) {
        ui->effortComboBox->setCurrentIndex(1); // default to 1 hour
    }
}
