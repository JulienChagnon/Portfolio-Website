#include "ics_import_dialog.h"
#include "ui_ics_import_dialog.h"  // auto-generated from .ui
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QDebug>

//constructor which sets up the UI and connects button signals
IcsImportDialog::IcsImportDialog(QWidget *parent)
    : QDialog(parent),
      ui(new Ui::IcsImportDialog)
{
    ui->setupUi(this);

    // Connect button clicks to their respective slots
    connect(ui->chooseButton, &QPushButton::clicked, this, &IcsImportDialog::chooseFile);
    connect(ui->importButton, &QPushButton::clicked, this, &IcsImportDialog::importFile);
    connect(ui->cancelButton, &QPushButton::clicked, this, &IcsImportDialog::cancelImport);
}

//destructor to clean up iu memory
IcsImportDialog::~IcsImportDialog()
{
    delete ui;
}

QString IcsImportDialog::selectedFilePath() const
{
    return selectedFile;
}

void IcsImportDialog::reset()
{
    selectedFile.clear();
    ui->fileNameField->clear();
    ui->importButton->setEnabled(false);
}
// opens file dialog and allows the user to select an .ics file
void IcsImportDialog::chooseFile()
{
    QString file = QFileDialog::getOpenFileName(this, "Select .ics File", "", "Calendar Files (*.ics)");
    if (!file.isEmpty()) {
        ui->fileNameField->setText(file); // display selected file name
        ui->importButton->setEnabled(true); //enable Import button
        selectedFile = file; //store path to yse later
    }
}

void IcsImportDialog::importFile()
{
    if (selectedFile.isEmpty()) {
        QMessageBox::warning(this, "No File", "Please choose a .ics file first.");
        return;
    }

    if (!QFile::exists(selectedFile)) {
        QMessageBox::warning(this, "File Missing", "The selected file can no longer be found. Please choose it again.");
        reset();
        return;
    }

    accept();
}


void IcsImportDialog::cancelImport()
{
    reset();
    reject();
}
