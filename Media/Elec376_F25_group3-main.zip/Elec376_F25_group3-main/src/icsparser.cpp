/* 
Goal of this file:
Reusable function that opens an .ics file exported from Solus
Extracts the information for each class, stores each event into a struct
Returns the list of events (to be used later)
*/

//TO TEST / DOWNLOAD .ICS from solus, just enter in terminal: curl -o solus_schedule.ics "https://mytimetable.queensu.ca/timetable//KM/22rb43-KMN5WPFS5ZIJCNCBEYWYDI7DKMM6N7Y4Y3Q6KR46FBTRIJL3T3TQ.ics"

#include <QFile>        //lets open/read files
#include <QTextStream>  //lets read file line by line
#include <QDateTime>    //parses calendar date formats
#include <QList>        //stores calendar events
#include <QString>      //Qt's string class
#include <QDebug>       // prints to terminal
#include <array>

// Step 1: Create a basic struct that'll store each class/event

struct CourseEvent {
    QString title;      // class name
    QString location;   // location
    QDateTime start;    // takes in as 20250929T103000
    QDateTime end;
    QString rrule;      // RRULE information for recurring events
    bool isRecurring;   // Flag to indicate if this is a recurring event
};

// Step 2: Parser function

// Declares a fnction that takes a QString file path as input, returns the course event struct, Qlist is a dynamic array from Qt that is helpful for this

namespace {
QDateTime parseIcsDateTime(const QString &raw)
{
    static const std::array<const char *, 4> formats = {
        "yyyyMMdd'T'HHmmss",
        "yyyyMMdd'T'HHmm",
        "yyyyMMddHHmmss",
        "yyyyMMddHHmm"
    };

    for (const char *fmt : formats) {
        QDateTime dt = QDateTime::fromString(raw, fmt);
        if (dt.isValid()) {
            return dt;
        }
    }

    return {};
}
}

QList<CourseEvent> parseIcsFile(const QString &filePath) {
    // Create an empty list to start, that'll ater store all parsed results
    QList<CourseEvent> events;
    //Open the proper file
    QFile file(filePath);

    // Open the .ics file
        //error checking: check if it exists, is readable
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        //if it fails, return an empty list and issue a warning
        qWarning() << "ERROR: ICS PARSER: Could not open the /ics file:" << filePath;
        return events;
    }

    // Read line by line
        //Qt's input stream, which is used to process text files more efficiently
        QTextStream in(&file);
        //temporary CourseEvent to hold the current event being read
        CourseEvent temp;

        //read each line one at a time until it reaches the end
        while (!in.atEnd()){
            QString line = in.readLine();
        

        //Each .ics file follows the iCalendar format (RFC 5545), which means each event looks like:
        /*
        BEGIN:VEVENT
        SUMMARY:ELEC 376 Lecture
        LOCATION:Jeffery 127
        DTSTART:20250929T103000
        DTEND:20250929T113000
        END:VEVENT
        */

        //Check through the starts of the lines to determine where you are in the parse
        if (line.startsWith("BEGIN:VEVENT")){
            temp = CourseEvent(); // when a new event is detected, clear the event struct
            temp.isRecurring = false; // Initialize as non-recurring
        } else if (line.startsWith("SUMMARY:")){
            temp.title = line.mid(8); //skip the prefix, Qt string are 0-indexed
        } else if (line.startsWith("LOCATION:")){
            temp.location = line.mid(9);
        } else if (line.startsWith("DTSTART:")) {
            QString dt = line.section(':',-1); //makes sure it's taking everything after the last colon
            temp.start = parseIcsDateTime(dt);
        } else if (line.startsWith("DTSTART;TZID=")) {
            QString dt = line.section(':',-1); //makes sure it's taking everything after the last colon
            temp.start = parseIcsDateTime(dt); //converts the timestamp format into something useable
        } else if (line.startsWith("DTEND:")) {
            QString dt = line.section(':',-1); //makes sure it's taking everything after the last colon
            temp.end = parseIcsDateTime(dt);
        } else if (line.startsWith("DTEND;TZID=")) {
            QString dt = line.section(':',-1); //makes sure it's taking everything after the last colon
            temp.end = parseIcsDateTime(dt);
        } else if (line.startsWith("RRULE:")) {
            temp.rrule = line.mid(6); // Store the RRULE information
            temp.isRecurring = true; // Mark as recurring event
        } else if (line.startsWith("END:VEVENT")) {
            if (!temp.start.isValid() || !temp.end.isValid()) {
                qWarning() << "[ICS Parser] Skipping event with invalid time values:" << temp.title;
                continue;
            }
            events.append(temp); //signal that full event's been parsed, copies the temp struct into the events list, continues the loop to wait for the next indication of start of an event
        }
    }
        //close the file, return the list of events
        file.close();
        return events;

    }
