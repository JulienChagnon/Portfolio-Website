#include "add_event_dialog.h"
#include "ui_add_event_dialog.h"
#include <QMessageBox>
#include <QComboBox>

namespace {
constexpr int HOURS_START = 8;
constexpr int HOURS_END = 23;
constexpr int SLOT_MINUTES = 30;
}

AddEventDialog::AddEventDialog(QWidget *parent)
    : QDialog(parent), ui(new Ui::AddEventDialog)
{
    ui->setupUi(this);
    ui->dateEdit->setDate(QDate::currentDate());
    populateStartTimes();

    connect(ui->startTimeCombo, qOverload<int>(&QComboBox::currentIndexChanged),
            this, &AddEventDialog::onStartTimeChanged);

    connect(ui->doneButton, &QPushButton::clicked, this, &AddEventDialog::onDone);
    connect(ui->cancelButton, &QPushButton::clicked, this, &AddEventDialog::reject);

    // Default to 4:00 PM start if available
    const int defaultStartIndex = ui->startTimeCombo->findData(QTime(16, 0));
    if (defaultStartIndex != -1) {
        ui->startTimeCombo->setCurrentIndex(defaultStartIndex);
    } else if (ui->startTimeCombo->count() > 0) {
        ui->startTimeCombo->setCurrentIndex(0);
    }
}

AddEventDialog::~AddEventDialog() { delete ui; }

CourseEvent AddEventDialog::event() const { return m_event; }

void AddEventDialog::onDone()
{
    const QString title = ui->titleEdit->text().trimmed();
    if (title.isEmpty()) {
        QMessageBox::warning(this, "Invalid Input", "Please provide a title for the event.");
        return;
    }

    const int startIndex = ui->startTimeCombo->currentIndex();
    const int endIndex = ui->endTimeCombo->currentIndex();
    if (startIndex < 0 || endIndex < 0) {
        QMessageBox::warning(this, "Invalid Time", "Please select both a start and end time.");
        return;
    }

    const QTime startTime = ui->startTimeCombo->currentData().toTime();
    const QTime endTime = ui->endTimeCombo->currentData().toTime();
    if (!startTime.isValid() || !endTime.isValid() || startTime >= endTime) {
        QMessageBox::warning(this, "Invalid Time", "Please make sure the end time is after the start time.");
        return;
    }

    QDate d = ui->dateEdit->date();
    m_event.title = title;
    m_event.location = ui->locationEdit->text().trimmed();
    m_event.start = QDateTime(d, startTime);
    m_event.end = QDateTime(d, endTime);
    m_event.isRecurring = false;

    accept();
}

void AddEventDialog::onStartTimeChanged(int index)
{
    if (index < 0) {
        ui->endTimeCombo->clear();
        return;
    }

    const QTime startTime = ui->startTimeCombo->itemData(index).toTime();
    populateEndTimes(startTime);
}

void AddEventDialog::populateStartTimes()
{
    ui->startTimeCombo->clear();
    const QTime lastPossibleEnd(HOURS_END, 0);

    for (int hour = HOURS_START; hour < HOURS_END; ++hour) {
        for (int minute : {0, 30}) {
            QTime time(hour, minute);
            if (!time.isValid()) continue;
            // Ensure there is at least one 30-minute slot after the start time
            if (time.addSecs(SLOT_MINUTES * 60) > lastPossibleEnd) {
                continue;
            }
            ui->startTimeCombo->addItem(formatDisplayTime(time), time);
        }
    }

    if (ui->startTimeCombo->count() > 0) {
        populateEndTimes(ui->startTimeCombo->itemData(0).toTime());
    } else {
        ui->endTimeCombo->clear();
    }
}

void AddEventDialog::populateEndTimes(const QTime &startTime)
{
    ui->endTimeCombo->clear();
    if (!startTime.isValid()) {
        return;
    }

    QTime endCandidate = startTime.addSecs(SLOT_MINUTES * 60);
    const QTime closing(HOURS_END, 0);

    while (endCandidate.isValid() && endCandidate <= closing) {
        ui->endTimeCombo->addItem(formatDisplayTime(endCandidate), endCandidate);
        endCandidate = endCandidate.addSecs(SLOT_MINUTES * 60);
    }

    if (ui->endTimeCombo->count() > 0) {
        ui->endTimeCombo->setCurrentIndex(0);
    }
}

QString AddEventDialog::formatDisplayTime(const QTime &time)
{
    return time.toString("h:mm AP");
}
