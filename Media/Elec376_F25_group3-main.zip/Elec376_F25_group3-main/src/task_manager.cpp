#include "task_manager.h"
#include "add_task_dialog.h"   // for TaskData struct
#include <QObject>
#include <QDebug>


TaskManager::TaskManager(QObject *parent)
    : QObject(parent)
{
}

void TaskManager::addTask(const TaskData &task)
{
    qDebug() << "[DEBUG] TaskManager received task:" << task.name;
    tasks.append(task);
    emit taskAdded(task);
}

const QList<TaskData> &TaskManager::getAllTasks() const
{
    return tasks;
}
