#include "main_window.h"
#include "task_manager.h"
#include <QApplication>
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QMessageBox>
#include <QFileInfo>
#include <QDebug>
#include <QScrollBar>
#include <QFont>
#include <QSizePolicy>
#include "task_data.h"
#include <algorithm>
#include <cmath>



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , centralWidget(nullptr)
    , mainLayout(nullptr)
    , toolbarLayout(nullptr)
    , calendarLayout(nullptr)
    , scrollArea(nullptr)
    , calendarWidget(nullptr)
    , prevWeekButton(nullptr)
    , nextWeekButton(nullptr)
    , currentWeekButton(nullptr)
    , weekLabel(nullptr)
    , inputScheduleButton(nullptr)
    , currentWeekStart(QDate::currentDate())
    , importDialog(nullptr)
{
    setupUI();
    setupMenuBar();
    setupToolBar();
    setupCalendarGrid();

    
    // Initialize to current week
    currentWeekStart = getWeekStart(QDate::currentDate());
    updateWeekDisplay();

    // --- Connect Task System ---
    taskManager = new TaskManager(this);
    connect(taskManager, &TaskManager::taskAdded, this, &MainWindow::onTaskAdded);
    connect(taskListPanel, &TaskListPanel::taskCreated, taskManager, &TaskManager::addTask);

}

MainWindow::~MainWindow()
{
    delete importDialog;
}

void MainWindow::setupUI()
{
    centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    
    // Create the horizontal layout for the left + right panels
    QHBoxLayout *outerLayout = new QHBoxLayout(centralWidget);
    outerLayout->setSpacing(15);
    outerLayout->setContentsMargins(10, 10, 10, 10);
    
    //create the task list panel (left sidebar)
    taskListPanel = new TaskListPanel(this);
    connect(taskListPanel, &TaskListPanel::eventAdded, this, &MainWindow::onEventAdded);

    // Create scroll area for the calendar
    scrollArea = new QScrollArea(this);
    scrollArea->setWidgetResizable(true);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

    //add widgets to the layout
    outerLayout->addWidget(taskListPanel, 1);
    outerLayout->addWidget(scrollArea, 3);

    //apply the layout
    centralWidget->setLayout(outerLayout);
    
    setWindowTitle("Weekly Schedule Viewer");
    setMinimumSize(1000, 700);
    resize(1200, 800);
}

void MainWindow::onEventAdded(const CourseEvent &event)
{
    // Add the new event to the in-memory event list
    allEvents.append(event);

    // If the newly added event is not in the currently visible week,
    // switch the calendar to that event's week so the user sees it immediately.
    QDate eventDate = event.start.date();
    QDate weekStartOfEvent = getWeekStart(eventDate);
    QDate currentWeekEnd = getWeekEnd(currentWeekStart);

    if (eventDate < currentWeekStart || eventDate > currentWeekEnd) {
        currentWeekStart = weekStartOfEvent;
    }

    // Refresh view to show the added event
    updateWeekDisplay();
}

void MainWindow::setupMenuBar()
{
    QMenuBar *menuBar = this->menuBar();
    
    QMenu *fileMenu = menuBar->addMenu("&File");
    QAction *importAction = fileMenu->addAction("&Import Schedule...");
    importAction->setShortcut(QKeySequence::Open);
    connect(importAction, &QAction::triggered, this, &MainWindow::openImportDialog);
    
    QMenu *viewMenu = menuBar->addMenu("&View");
    QAction *currentWeekAction = viewMenu->addAction("&Current Week");
    currentWeekAction->setShortcut(QKeySequence("Ctrl+Home"));
    connect(currentWeekAction, &QAction::triggered, this, &MainWindow::goToCurrentWeek);
    
    QMenu *helpMenu = menuBar->addMenu("&Help");
    QAction *aboutAction = helpMenu->addAction("&About");
    connect(aboutAction, &QAction::triggered, [this]() {
        QMessageBox::about(this, "About", 
            "Weekly Schedule Viewer\n\n"
            "A Qt application for viewing weekly schedules from ICS calendar files.\n"
            "Built with Qt 6.9.3");
    });
}

void MainWindow::setupToolBar()
{
    QToolBar *toolBar = addToolBar("Main Toolbar");
    toolBar->setMovable(false);
    
    // Week navigation
    prevWeekButton = new QPushButton("◀ Previous Week", this);
    prevWeekButton->setMaximumWidth(150);
    connect(prevWeekButton, &QPushButton::clicked, this, &MainWindow::previousWeek);
    toolBar->addWidget(prevWeekButton);
    
    currentWeekButton = new QPushButton("Current Week", this);
    currentWeekButton->setMaximumWidth(120);
    connect(currentWeekButton, &QPushButton::clicked, this, &MainWindow::goToCurrentWeek);
    toolBar->addWidget(currentWeekButton);
    
    nextWeekButton = new QPushButton("Next Week ▶", this);
    nextWeekButton->setMaximumWidth(150);
    connect(nextWeekButton, &QPushButton::clicked, this, &MainWindow::nextWeek);
    toolBar->addWidget(nextWeekButton);
    
    toolBar->addSeparator();
    
    // Week label
    weekLabel = new QLabel(this);
    weekLabel->setStyleSheet("font-weight: bold; font-size: 13px;");
    toolBar->addWidget(weekLabel);
    
    toolBar->addSeparator();
    
    // Input schedule button
    inputScheduleButton = new QPushButton("📅 Input Schedule", this);
    inputScheduleButton->setMaximumWidth(150);
    inputScheduleButton->setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-weight: bold; }");
    connect(inputScheduleButton, &QPushButton::clicked, this, &MainWindow::openImportDialog);
    toolBar->addWidget(inputScheduleButton);
    
    toolBar->addSeparator();
    
    // Status bar
    statusBar()->showMessage("Ready - Import a schedule to get started");
}

void MainWindow::setupCalendarGrid()
{
    calendarWidget = new QWidget();
    calendarLayout = new QGridLayout(calendarWidget);
    calendarLayout->setSpacing(0); // No spacing between grid cells
    calendarLayout->setContentsMargins(2, 2, 2, 2);
    calendarLayout->setColumnStretch(0, 0);
    
    // Create day headers
    QStringList dayNames = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    for (int day = 0; day < 7; ++day) {
        QLabel *dayHeader = new QLabel(dayNames[day], this);
        dayHeader->setAlignment(Qt::AlignCenter);
        dayHeader->setStyleSheet(
            "QLabel { "
            "background-color: #2196F3; "
            "color: white; "
            "font-weight: bold; "
            "font-size: 11px; "
            "padding: 3px; "
            "border: 1px solid #000000; "
            "border-radius: 6px; "
            "margin: 0px; "
            "}"
        );
        dayHeader->setMinimumHeight(32);
        dayHeader->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        calendarLayout->addWidget(dayHeader, 0, day + 1);
        dayHeaders.append(dayHeader);
        calendarLayout->setColumnStretch(day + 1, 1);
    }
    
    // Create time slots
    timeSlots.resize(7); // 7 days
    for (int day = 0; day < 7; ++day) {
        timeSlots[day].resize(TIME_SLOTS_PER_DAY);
        for (int slot = 0; slot < TIME_SLOTS_PER_DAY; ++slot) {
            QLabel *timeSlot = new QLabel("", this);
            timeSlot->setMinimumHeight(40);
            timeSlot->setMaximumHeight(40);
            timeSlot->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
            timeSlot->setAlignment(Qt::AlignTop | Qt::AlignLeft);
            timeSlot->setStyleSheet(
                "QLabel { "
                "border: 1px solid #CCCCCC; "
                "background-color: white; "
                "padding: 2px; "
                "font-size: 9px; "
                "margin: 0px; "
                "}"
            );
            timeSlot->setWordWrap(true);
            timeSlot->setProperty("event_occupied", false);
            calendarLayout->addWidget(timeSlot, slot + 1, day + 1);
            timeSlots[day][slot] = timeSlot;
        }
    }
    
    // Create time labels on the left
// Create time labels on the left (every 30 minutes)
int row = 1;
for (int hour = HOURS_START; hour < HOURS_END; ++hour) {
    for (int minute = 0; minute < 60; minute += 30) {
        QTime displayTime(hour, minute);
        QString timeText = displayTime.toString("h:mm AP");

        QLabel *timeLabel = new QLabel(timeText, this);
        timeLabel->setAlignment(Qt::AlignCenter);
        timeLabel->setStyleSheet(
            "QLabel { "
            "background-color: #F8F9FA; "
            "border: 1px solid #CCCCCC; "
            "font-weight: bold; "
            "font-size: 9px; "
            "padding: 3px; "
            "margin: 0px; "
            "}"
        );
        timeLabel->setMinimumSize(50, 20);
        timeLabel->setMaximumSize(50, 20);

        calendarLayout->addWidget(timeLabel, row, 0);
        row++;
    }
}
    
    scrollArea->setWidget(calendarWidget);
}

void MainWindow::updateWeekDisplay()
{
    QDate weekEnd = getWeekEnd(currentWeekStart);
    QString weekText = QString("Week of %1 - %2")
        .arg(currentWeekStart.toString("MMM dd"))
        .arg(weekEnd.toString("MMM dd, yyyy"));
    weekLabel->setText(weekText);
    
    // Update day headers with actual dates
    for (int day = 0; day < 7; ++day) {
        QDate dayDate = currentWeekStart.addDays(day);
        QString dayText = QString("%1\n%2")
            .arg(dayHeaders[day]->text().split('\n')[0]) // Keep day name
            .arg(dayDate.toString("MMM dd"));
        dayHeaders[day]->setText(dayText);
    }
    
    populateSchedule();
}

void MainWindow::populateSchedule()
{
    clearSchedule();
    
    if (allEvents.isEmpty()) {
        return;
    }
    
    QList<CourseEvent> weekEvents = mergeAdjacentEvents(getEventsForWeek(currentWeekStart));

    const QString singleBlockStyle =
        "QLabel { "
        "border: 1px solid #1976D2; "
        "background-color: #E3F2FD; "
        "padding: 6px; "
        "font-size: 9px; "
        "font-weight: bold; "
        "color: #0D47A1; "
        "border-radius: 6px; "
        "margin: 0px; "
        "}";

    const QString multiBlockStyle =
        "QLabel { "
        "border: 1px solid #1976D2; "
        "background-color: #E3F2FD; "
        "padding: 6px; "
        "font-size: 9px; "
        "font-weight: bold; "
        "color: #0D47A1; "
        "border-radius: 6px; "
        "margin: 0px; "
        "}";

    for (const CourseEvent &event : weekEvents) {
        int dayOfWeek = event.start.date().dayOfWeek() - 1;
        if (dayOfWeek < 0 || dayOfWeek >= 7) continue;

        int startHour = event.start.time().hour();
        int startMinute = event.start.time().minute();
        int endHour = event.end.time().hour();
        int endMinute = event.end.time().minute();
        
        int totalSlotsPerHour = 2;
        int slot = (startHour - HOURS_START) * totalSlotsPerHour + (startMinute >= 30 ? 1 : 0);

        int durationMinutes = (endHour * 60 + endMinute) - (startHour * 60 + startMinute);
        if (durationMinutes <= 0) {
            continue;
        }

        int slotSpan = std::ceil(durationMinutes / 30.0);

        if (slot < 0 || slot >= TIME_SLOTS_PER_DAY) continue;

        slotSpan = std::min(slotSpan, TIME_SLOTS_PER_DAY - slot);
        if (slotSpan <= 0) {
            continue;
        }

        QString startTime = event.start.toString("h:mm");
        QString endTime = event.end.toString("h:mm");
        QString startAmPm = event.start.time().hour() < 12 ? "AM" : "PM";
        QString endAmPm = event.end.time().hour() < 12 ? "AM" : "PM";
        
        QString timeString;
        if (startAmPm == endAmPm) {
            timeString = QString("%1 - %2 %3").arg(startTime).arg(endTime).arg(startAmPm);
        } else {
            timeString = QString("%1 %2 - %3 %4").arg(startTime).arg(startAmPm).arg(endTime).arg(endAmPm);
        }
        
        QString eventText = QString("%1\n%2\n%3")
            .arg(event.title)
            .arg(event.location)
            .arg(timeString);

        // Check for collisions
        bool collision = false;
        for (int i = 0; i < slotSpan; ++i) {
            const int targetSlot = slot + i;
            if (targetSlot >= TIME_SLOTS_PER_DAY) {
                collision = true;
                break;
            }
            QLabel *cell = timeSlots[dayOfWeek][targetSlot];
            if (cell->property("event_occupied").toBool()) {
                collision = true;
                break;
            }
        }

        if (collision) {
            QLabel *primaryCell = timeSlots[dayOfWeek][slot];
            QString stackedText = primaryCell->text();
            if (!stackedText.isEmpty()) {
                stackedText += "\n\n";
            }
            stackedText += eventText;
            primaryCell->setText(stackedText);
            primaryCell->setStyleSheet(singleBlockStyle);
            primaryCell->setProperty("event_occupied", true);
            continue;
        }

        // For multi-slot events, remove the individual cells and add a spanning label
        if (slotSpan > 1) {
            // Hide the individual slot labels
            for (int i = 0; i < slotSpan; ++i) {
                const int targetSlot = slot + i;
                QLabel *cell = timeSlots[dayOfWeek][targetSlot];
                cell->hide();
                cell->setProperty("event_occupied", true);
            }
            
            // Create a new label that spans multiple rows
            QLabel *spanningLabel = new QLabel(eventText, calendarWidget);
            spanningLabel->setAlignment(Qt::AlignTop | Qt::AlignLeft);
            spanningLabel->setWordWrap(true);
            spanningLabel->setStyleSheet(multiBlockStyle);
            spanningLabel->setMinimumHeight(40 * slotSpan);
            spanningLabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
            
            // Add to layout spanning multiple rows
            calendarLayout->addWidget(spanningLabel, slot + 1, dayOfWeek + 1, slotSpan, 1);
        } else {
            // Single slot event
            QLabel *cell = timeSlots[dayOfWeek][slot];
            cell->setText(eventText);
            cell->setStyleSheet(singleBlockStyle);
            cell->setProperty("event_occupied", true);
        }
    }
}

void MainWindow::clearSchedule()
{
    for (int day = 0; day < 7; ++day) {
        for (int slot = 0; slot < TIME_SLOTS_PER_DAY; ++slot) {
            timeSlots[day][slot]->setText("");
            timeSlots[day][slot]->setStyleSheet(
                "QLabel { "
                "border: 1px solid #CCCCCC; "
                "background-color: white; "
                "padding: 3px; "
                "font-size: 10px; "
                "margin: 0px; "
                "}"
            );
            timeSlots[day][slot]->setProperty("event_occupied", false);
            timeSlots[day][slot]->setMaximumHeight(40);
            timeSlots[day][slot]->show();
        }
    }
}

QDate MainWindow::getWeekStart(const QDate &date) const
{
    int dayOfWeek = date.dayOfWeek();
    return date.addDays(-(dayOfWeek - 1)); // Monday = 1, so subtract (dayOfWeek - 1)
}

QDate MainWindow::getWeekEnd(const QDate &date) const
{
    return getWeekStart(date).addDays(6);
}

QList<CourseEvent> MainWindow::getEventsForWeek(const QDate &weekStart) const
{
    QDate weekEnd = getWeekEnd(weekStart);
    QList<CourseEvent> weekEvents;
    
    for (const CourseEvent &event : allEvents) {
        QDate eventDate = event.start.date();
        
        // Check if this is a recurring weekly event
        if (isRecurringWeeklyEvent(event)) {
            // For recurring events, check if this week falls within the semester
            if (isEventActiveInWeek(event, weekStart)) {
                // Create a copy of the event for this specific week
                CourseEvent weeklyEvent = event;
                
                // Place this recurring event on its weekday within the current week (Mon=1)
                int eventDayOfWeek = event.start.date().dayOfWeek(); // 1..7
                int daysOffset = eventDayOfWeek - 1;                  // 0..6 from Monday
                
                QDate adjustedDate = weekStart.addDays(daysOffset);
                QTime startTime = event.start.time();
                QTime endTime = event.end.time();
                
                weeklyEvent.start = QDateTime(adjustedDate, startTime);
                weeklyEvent.end = QDateTime(adjustedDate, endTime);
                
                weekEvents.append(weeklyEvent);
            }
        } else {
            // For non-recurring events, check if they fall within this week
            if (eventDate >= weekStart && eventDate <= weekEnd) {
                weekEvents.append(event);
            }
        }
    }
    
    return weekEvents;
}

QList<CourseEvent> MainWindow::mergeAdjacentEvents(const QList<CourseEvent> &events) const
{
    if (events.isEmpty()) {
        return {};
    }

    QList<CourseEvent> sortedEvents = events;
    std::sort(sortedEvents.begin(), sortedEvents.end(), [](const CourseEvent &a, const CourseEvent &b) {
        if (a.start == b.start) {
            if (a.end == b.end) {
                return a.title < b.title;
            }
            return a.end < b.end;
        }
        return a.start < b.start;
    });

    QList<CourseEvent> merged;
    merged.reserve(sortedEvents.size());

    for (const CourseEvent &event : sortedEvents) {
        if (merged.isEmpty()) {
            merged.append(event);
            continue;
        }

        CourseEvent &last = merged.last();
        const bool sameDay = last.start.date() == event.start.date();
        const bool sameTitle = last.title == event.title;
        const bool sameLocation = last.location == event.location;
        const bool sameRecurrence = last.rrule == event.rrule;
        const bool contiguous = last.end == event.start;

        if (sameDay && sameTitle && sameLocation && sameRecurrence && contiguous) {
            last.end = event.end;
        } else {
            merged.append(event);
        }
    }

    return merged;
}

QList<CourseEvent> MainWindow::getEventsForDay(const QDate &date) const
{
    QList<CourseEvent> dayEvents;
    
    for (const CourseEvent &event : allEvents) {
        if (event.start.date() == date) {
            dayEvents.append(event);
        }
    }
    
    return dayEvents;
}

bool MainWindow::isRecurringWeeklyEvent(const CourseEvent &event) const
{
    // Use the isRecurring flag from the parsed RRULE
    return event.isRecurring;
}

bool MainWindow::isEventActiveInWeek(const CourseEvent &event, const QDate &weekStart) const
{
    const QDate weekEnd = getWeekEnd(weekStart);

    // Event's natural start/end window:
    const QDate eventStart = event.start.date();

    // Default end = start (single or recurring with unknown end)
    QDate eventEnd = eventStart;

    // If recurring and RRULE has UNTIL=YYYYMMDD..., use that as the end (inclusive)
    if (event.isRecurring && !event.rrule.isEmpty()) {
        const int untilIdx = event.rrule.indexOf("UNTIL=");
        if (untilIdx != -1) {
            QString untilStr = event.rrule.mid(untilIdx + 6);
            const int semi = untilStr.indexOf(';');
            if (semi != -1) untilStr = untilStr.left(semi);
            // UNTIL can be date or date-time; keep only yyyymmdd
            const QString ymd = untilStr.left(8);
            const QDate until = QDate::fromString(ymd, "yyyyMMdd");
            if (until.isValid()) {
                eventEnd = until;
            }
        }
    }

    // Show this event in this week iff [weekStart, weekEnd] overlaps [eventStart, eventEnd]
    if (weekEnd < eventStart) return false;
    if (weekStart > eventEnd) return false;

    return true;
}


void MainWindow::openImportDialog()
{
    if (!importDialog) {
        importDialog = new IcsImportDialog(this);
    }

    importDialog->reset();

    if (importDialog->exec() == QDialog::Accepted) {
        const QString fileName = importDialog->selectedFilePath();
        if (!fileName.isEmpty()) {
            onScheduleImported(fileName);
        }
    }
}

void MainWindow::onScheduleImported(const QString &filePath)
{
    allEvents = parseIcsFile(filePath);
    
    if (allEvents.isEmpty()) {
        QMessageBox::warning(this, "Import Failed", 
            "No events found in the selected file.\nPlease check that the file is a valid ICS calendar file.");
        return;
    }
    
    // Update status bar
    statusBar()->showMessage(QString("Loaded %1 events from %2")
        .arg(allEvents.size())
        .arg(QFileInfo(filePath).baseName()));
    
    // Refresh the current week display
    updateWeekDisplay();
    
    QMessageBox::information(this, "Import Successful", 
        QString("Successfully imported %1 events!\nThe schedule is now displayed in the weekly view.")
        .arg(allEvents.size()));
}

void MainWindow::previousWeek()
{
    currentWeekStart = currentWeekStart.addDays(-7);
    updateWeekDisplay();
}

void MainWindow::nextWeek()
{
    currentWeekStart = currentWeekStart.addDays(7);
    updateWeekDisplay();
}

void MainWindow::goToCurrentWeek()
{
    currentWeekStart = getWeekStart(QDate::currentDate());
    updateWeekDisplay();
}

void MainWindow::onTaskAdded(const TaskData &task)
{
    qDebug() << "[DEBUG] MainWindow::onTaskAdded() called for task:" << task.name;

    QDate today = QDate::currentDate();
    QDate due = task.dueDate;
    QDate startSearch = getWeekStart(today);
    QDate endSearch = due;
    
    // number of 30-minute blocks needed
    int requiredSlots = static_cast<int>(std::ceil(task.effortHours / 0.5));
    int filledSlots = 0;
    
    for (QDate day = startSearch; day <= endSearch && filledSlots < requiredSlots; day = day.addDays(1)) {
        QList<CourseEvent> dayEvents = getEventsForDay(day);
    
        // skip past days entirely
        if (day < today) continue;
    
        for (int slot = 0; slot < timeSlots[0].size() && filledSlots < requiredSlots; ++slot) {
            // compute this slot's absolute time
            int totalMinutes = HOURS_START * 60 + slot * 30;
            int hour = totalMinutes / 60;
            int minute = totalMinutes % 60;
            QTime slotStart(hour, minute);
    
            // skip if this slot is before the current time on today's date
            if (day == today && slotStart < QTime::currentTime()) continue;
    
            // check overlap with any event
            bool overlaps = false;
            for (const CourseEvent &e : dayEvents) {
                if (slotStart >= e.start.time() && slotStart < e.end.time()) {
                    overlaps = true;
                    break;
                }
            }
    
            if (overlaps) continue;
    
            // find the label for this slot
            int dayOfWeek = day.dayOfWeek() - 1;
            QLabel *label = timeSlots[dayOfWeek][slot];
            if (label->property("event_occupied").toBool()) {
                continue;
            }
            if (label->text().isEmpty()) {
                label->setText(QString("🧠 Study: %1\nDue: %2")
                               .arg(task.name)
                               .arg(task.dueDate.toString("MMM d")));
                label->setStyleSheet(
                    "QLabel { "
                    "border: 1px solid #1565C0; "
                    "background-color: #E1F5FE; "
                    "font-size: 9px; "
                    "font-weight: bold; "
                    "color: #0D47A1; "
                    "border-radius: 5px; "
                    "padding: 3px; }");
                label->setProperty("event_occupied", true);
                filledSlots++;
            }
        }
    }
    
    if (filledSlots < requiredSlots) {
        QMessageBox::warning(this, "No Available Slot",
                             QString("Only found %1 of %2 half-hour slots before %3 for task '%4'.")
                             .arg(filledSlots)
                             .arg(requiredSlots)
                             .arg(task.dueDate.toString("MMM d"))
                             .arg(task.name));
    }

}
