#include "welcome_dialog.h"
#include <QFont>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QCheckBox>

WelcomeDialog::WelcomeDialog(QWidget *parent)
    : QDialog(parent)
{
    setupUI();
    setWindowTitle("Welcome to Weekly Schedule Viewer");
    setModal(true);
    setMinimumSize(600, 500);
    resize(650, 550);
}

WelcomeDialog::~WelcomeDialog() {}

void WelcomeDialog::setupUI()
{
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->setSpacing(20);
    layout->setContentsMargins(20, 20, 20, 20);

    titleLabel = new QLabel("Welcome to Weekly Schedule Viewer!", this);
    QFont titleFont;
    titleFont.setPointSize(18);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    titleLabel->setAlignment(Qt::AlignCenter);
    layout->addWidget(titleLabel);

    // Instructions scroll area
    QScrollArea *scrollArea = new QScrollArea(this);
    scrollArea->setWidgetResizable(true);
    QLabel *instructionsLabel = new QLabel(this);
    instructionsLabel->setWordWrap(true);
    instructionsLabel->setTextFormat(Qt::RichText);
    instructionsLabel->setText(
        "<p style='font-size: 14px;'>"
        "This application allows you to manage your school schedule by importing ICS calendar files "
        "and organizing your weekly timetable."
        "</p>"
        "<p style='font-size: 13px; font-weight: bold; color: #1976D2;'>Getting Started:</p>"
        "<ul style='font-size: 12px;'>"
        "<li><b>Import Your Schedule:</b> Click the Input Schedule button list</li>"
        "<li><b>View Your Week:</b> Move between weeks with the Previous/Next Week buttons list</li>"
        "<li><b>Add Tasks:</b> Use the left sidebar to create tasks list</li>"
        "<li><b>Auto-Schedule Study Time:</b> The app will find the available time slots to fit your study sessions in correctly</li>"
        "</ul>"
    );
    instructionsLabel->setStyleSheet("QLabel { background-color: #F5F5F5; padding: 10px; border-radius: 5px; }");
    scrollArea->setWidget(instructionsLabel);
    layout->addWidget(scrollArea);

    layout->addStretch();


    QHBoxLayout *buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();

    getStartedButton = new QPushButton("Get Started", this);
    getStartedButton->setMinimumSize(150, 40);
    getStartedButton->setStyleSheet(
        "QPushButton {"
        "  background-color: #1976D2;"  // blue
        "  color: white;"
        "  border-radius: 5px;"
        "}"
        "QPushButton:hover {"
        "  background-color: #1565C0;"  // darker blue on hover
        "}"
    );
    connect(getStartedButton, &QPushButton::clicked, this, &QDialog::accept);
    buttonLayout->addWidget(getStartedButton);

    importIcsButton = new QPushButton("Import Schedule Now", this);
    importIcsButton->setMinimumSize(150, 40);
    importIcsButton->setStyleSheet(
        "QPushButton {"
        "  background-color: #388E3C;"  // green
        "  color: white;"
        "  border-radius: 5px;"
        "}"
        "QPushButton:hover {"
        "  background-color: #2E7D32;"  // darker green on hover
        "}"
    );
    connect(importIcsButton, &QPushButton::clicked, this, &WelcomeDialog::openIcsImportDialogRequested);
    buttonLayout->addWidget(importIcsButton);

    buttonLayout->addStretch();
    layout->addLayout(buttonLayout);
}