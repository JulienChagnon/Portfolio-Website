#include <QApplication>
#include <QDebug>
#include <QFile>
#include <QDir>
#include <QTextStream>
#include <QDateTime>
#include "main_window.h"
#include "welcome_dialog.h"

void fileMessageHandler(QtMsgType type, const QMessageLogContext &, const QString &msg)
{
    QString logPath = QDir::homePath() + "/Elec376_debug.log";
    QFile logFile(logPath);
    if (logFile.open(QIODevice::Append | QIODevice::Text))
    {
        QTextStream ts(&logFile);
        ts << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss ")
           << msg << Qt::endl;
    }
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    
    // Install custom log handler
    qInstallMessageHandler(fileMessageHandler);
    
    // Show main window immediately
    MainWindow mainWindow;
    mainWindow.show();
    
    // Show welcome dialog non-modally
    WelcomeDialog *welcomeDialog = new WelcomeDialog(&mainWindow); // Make mainWindow the parent
    welcomeDialog->show(); // non-modal
    
    // Connect "Import Schedule Now" button to MainWindow's import function
    QObject::connect(welcomeDialog, &WelcomeDialog::openIcsImportDialogRequested, 
                     &mainWindow, [&mainWindow, welcomeDialog]() {
        welcomeDialog->close();              // close the welcome dialog
        mainWindow.openImportDialog();       // call MainWindow's import method
    });
    
    return app.exec();
}