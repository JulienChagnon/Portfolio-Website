#ifndef TASK_DATA_H
#define TASK_DATA_H

#include <QString>
#include <QDate>

// Simple data container for each user-created task
struct TaskData
{
    QString name;          // e.g. "Math assignment"
    QDate dueDate;         // e.g. 2025-10-31
    double effortHours;    // numeric value, e.g. 1.5 = 1h30
    QString priority;      // e.g. "High", "Medium", "Low"
};

#endif // TASK_DATA_H
