#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <QScrollArea>
#include <QDate>
#include <QList>
#include "ics_import_dialog.h"
#include "icsparser.h"
#include "task_list_panel.h"


class TaskManager;

QT_BEGIN_NAMESPACE
class QCalendarWidget;
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots: 
    void openImportDialog();

private slots:
    void previousWeek();
    void nextWeek();
    void goToCurrentWeek();
    void onScheduleImported(const QString &filePath);
    void onEventAdded(const CourseEvent &event);

private:
    void setupUI();
    void setupMenuBar();
    void setupToolBar();
    void setupCalendarGrid();
    void updateWeekDisplay();
    void populateSchedule();
    void clearSchedule();
    QDate getWeekStart(const QDate &date) const;
    QDate getWeekEnd(const QDate &date) const;
    QString formatTimeSlot(int hour, int minute) const;
    QList<CourseEvent> getEventsForWeek(const QDate &weekStart) const;
    QList<CourseEvent> getEventsForDay(const QDate &date) const;
    bool isRecurringWeeklyEvent(const CourseEvent &event) const;
    bool isEventActiveInWeek(const CourseEvent &event, const QDate &weekStart) const;
    QList<CourseEvent> mergeAdjacentEvents(const QList<CourseEvent> &events) const;

    TaskManager *taskManager;
    void onTaskAdded(const TaskData &task);

    // UI Components
    QWidget *centralWidget;
    QVBoxLayout *mainLayout;
    QHBoxLayout *toolbarLayout;
    QGridLayout *calendarLayout;
    QScrollArea *scrollArea;
    QWidget *calendarWidget;
    
    // Navigation
    QPushButton *prevWeekButton;
    QPushButton *nextWeekButton;
    QPushButton *currentWeekButton;
    QLabel *weekLabel;
    
    // Schedule input
    QPushButton *inputScheduleButton;
    
    // Calendar grid (7 days x time slots)
    QList<QLabel*> dayHeaders;
    QVector<QVector<QLabel*>> timeSlots;      // [day][time_slot] background cells
    
    // Data
    QList<CourseEvent> allEvents;
    QDate currentWeekStart;
    IcsImportDialog *importDialog;

    //Task pannel
    TaskListPanel *taskListPanel;
    
    // Constants (30-minute slots from 8 AM to 11 PM)
    static const int HOURS_START = 8;
    static const int HOURS_END = 23;  // 11 PM
    static const int TIME_SLOTS_PER_DAY = (HOURS_END - HOURS_START) * 2; // 30-min intervals

};

#endif // MAIN_WINDOW_H
