#ifndef ICS_IMPORT_DIALOG_H
#define ICS_IMPORT_DIALOG_H

#include <QDialog>

QT_BEGIN_NAMESPACE
namespace Ui { class IcsImportDialog; }
QT_END_NAMESPACE

class IcsImportDialog : public QDialog
{
    Q_OBJECT

public:
    // contructor
    explicit IcsImportDialog(QWidget *parent = nullptr); 
    //destructor
    ~IcsImportDialog();

    QString selectedFilePath() const;
    void reset();

    //define method slots
private slots:
    void chooseFile(); //opens file dialog
    void importFile(); //calls the parser
    void cancelImport(); //closes the window

private:
    Ui::IcsImportDialog *ui;
    QString selectedFile;
};

#endif // ICS_IMPORT_DIALOG_H
