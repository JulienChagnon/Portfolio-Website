#ifndef ADD_EVENT_DIALOG_H
#define ADD_EVENT_DIALOG_H

#include <QDialog>
#include "icsparser.h"
#include <QTime>

namespace Ui { class AddEventDialog; }

class AddEventDialog : public QDialog {
    Q_OBJECT
public:
    explicit AddEventDialog(QWidget *parent = nullptr);
    ~AddEventDialog();

    CourseEvent event() const;

private slots:
    void onDone();
    void onStartTimeChanged(int index);

private:
    void populateStartTimes();
    void populateEndTimes(const QTime &startTime);
    static QString formatDisplayTime(const QTime &time);

    Ui::AddEventDialog *ui;
    CourseEvent m_event;
};

#endif // ADD_EVENT_DIALOG_H
