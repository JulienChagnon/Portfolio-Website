#ifndef TASK_LIST_PANEL_H
#define TASK_LIST_PANEL_H

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QListWidget>
#include <QPushButton>
#include "add_task_dialog.h"
#include "icsparser.h"

class AddEventDialog;

//the taskListPanel shows the list of tasks on the left side of the main window
class TaskListPanel : public QWidget {
    Q_OBJECT

    //constructor to set up layout and widgets
public:
    explicit TaskListPanel(QWidget *parent = nullptr);

    //slot to open the add task dialog when the button is pressed
private slots:
    void openAddTaskDialog();
    void openAddEventDialog();
    void editTask(QListWidgetItem *item);
    void deleteTask(QListWidgetItem *item);

signals:
    void taskCreated(const TaskData &task);

private:
    QVBoxLayout *layout;    //controls vertical arrangement of widgets
    QListWidget *taskList;  //displys all tasks as a list item
    QPushButton *addButton; //the add task button at the bottom of the screen
    QPushButton *addEventButton; //button to add a calendar event

signals:
    void eventAdded(const CourseEvent &event);
};

#endif
