#ifndef WELCOME_DIALOG_H
#define WELCOME_DIALOG_H

#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>

class WelcomeDialog : public QDialog
{
    Q_OBJECT

public:
    explicit WelcomeDialog(QWidget *parent = nullptr);
    ~WelcomeDialog();

signals:
    void openIcsImportDialogRequested(); 

private:
    void setupUI();

    QVBoxLayout *mainLayout;
    QLabel *titleLabel;
    QLabel *instructionsLabel;
    QPushButton *getStartedButton;
    QPushButton *importIcsButton;       
};

#endif
