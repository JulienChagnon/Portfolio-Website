#ifndef ICSPARSER_H
#define ICSPARSER_H

#include <QList>
#include <QString>
#include <QDateTime>

//struct to store information for one calendar event
struct CourseEvent {
    QString title;
    QString location;
    QDateTime start;
    QDateTime end;
    QString rrule;  
    bool isRecurring;
};

// function that reads and parses an .ics file and returns a list of CourseEvent objects
QList<CourseEvent> parseIcsFile(const QString &filePath);

#endif
