#ifndef TASK_MANAGER_H
#define TASK_MANAGER_H

#include <QObject>
#include <QList>
#include <QDebug>
#include "add_task_dialog.h"
#include "icsparser.h"

class TaskManager : public QObject {
    Q_OBJECT

public:
    explicit TaskManager(QObject *parent = nullptr);

    void addTask(const TaskData &task);
    const QList<TaskData> &getAllTasks() const;

signals:
    void taskAdded(const TaskData &task);

private:
    QList<TaskData> tasks;
};

#endif
