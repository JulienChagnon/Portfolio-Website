To pull the latest version and run the project:

# Mac:

git pull
mkdir build
cd build
cmake .. -DCMAKE_PREFIX_PATH=$(brew --prefix qt6)
cmake --build .
./IcsImporterApp

# PC:
git pull
mkdir build
cd build
cmake .. -DCMAKE_PREFIX_PATH="C:/Qt/6.5.0/msvc2019_64"
cmake --build . --config Release
.\IcsImporterApp.exe

# PC (mingw Qt):
git pull
mkdir build
cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_PREFIX_PATH="C:/Qt/6.9.3/mingw_64"

cmake --build build
cd build
$env:PATH += ";C:\Qt\6.9.3\mingw_64\bin"
.\IcsImporterApp.exe